<?php

namespace xyz;

use pocketmine\plugin\PluginBase;
use pocketmine\Server;

/** @var Players */
use pocketmine\player\Player;

/** @var Utils */
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

/** @var FormAPIUI */
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;

/** @var Windowy Dependecy (null)*/
use DayKoala\Windowy as Packet;
use DayKoala\inventory\WindowIds as Type;
use DayKoala\inventory\WindowFactory;
use DayKoala\inventory\action\WindowTransaction as WPacket;

/** @var Other Dependecys */
use onebone\economyapi\EconomyAPI;

/** @var Acessible Configs */
use xyz\library\MagicPE;
use xyz\commands\MagicC;

/** @var Enchants */
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\data\bedrock\EnchantmentIds;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\ItemFlags;
use pocketmine\item\enchantment\Rarity;
use pocketmine\lang\KnownTranslationFactory;

/** @var Other */
use pocketmine\item\Tool;
use pocketmine\item\Sword;
use pocketmine\item\Axe;
use pocketmine\item\Armor;

/** @var Commands */
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

/** @var class */
class MagicUI extends PluginBase{
  
  //public $cooldown = [];
  
  public static $instance = null;
  public static function getInstance() {
    return self::$instance;
  }
  
  public $ench = [];
  public $explosion = "Explosion I";
  
  /** @var Pocketmine */
    /**
  public function onLoad(): void {
    //null
  } */
  public function onEnable(): void {
    @mkdir($this->getDataFolder());
    $this->getServer()->getPluginManager()->registerEvents(new MagicPE($this), $this);
   // $this->getServer()->getCommandMap()->register("MagicC", new MagicC($this));
      
      self::$instance = $this;
    
    $this->db = new Config($this->getDataFolder()."config.yml", Config::YAML, [
      "permission-discount" => "discount.perm",
      "discount-in-coins" => 100,
      #-------------------
      "eff1-cost" => 350,
      "eff2-cost" => 550,
      "eff3-cost" => 750,
      "eff4-cost" => 950,
      "eff5-cost" => 1150,
      "eff6-cost" => 1350,
      "eff7-cost" => 1550,
      "eff8-cost" => 1750,
      "eff9-cost" => 1950,
      "eff10-cost" => 2150,
      #-------------------
      "unb1-cost" => 350,
      "unb2-cost" => 550,
      "unb3-cost" => 750,
      "unb4-cost" => 950,
      "unb5-cost" => 1150,
      "unb6-cost" => 1350,
      "unb7-cost" => 1550,
      #-------------------
      "for1-cost" => 550,
      "for2-cost" => 790,
      "for3-cost" => 990,
      #-------------------
      "silk-cost" => 1000,
      #-------------------
      "sharp1-cost" => 350,
      "sharp2-cost" => 550,
      "sharp3-cost" => 750,
      "sharp4-cost" => 950,
      "sharp5-cost" => 1150,
      "sharp6-cost" => 1350,
      "sharp7-cost" => 1550,
      #-------------------
      "fire1-cost" => 350,
      "fire2-cost" => 750,
      #-------------------
      "loot1-cost" => 450,
      "loot2-cost" => 650,
      "loot3-cost" => 850,
      #-------------------
      "protect1-cost" => 550,
      "protect2-cost" => 750,
      "protect3-cost" => 950,
      "protect4-cost" => 1050,
      "protect5-cost" => 1350,
      "protect6-cost" => 1550,
      "protect7-cost" => 2000,
      #-------------------
      "exp1-cost" => 250
    ]);
    
   /** 
    $this->utils = new Config($this->getDataFolder()."task.yml", Config::YAML, [
      "cooldown-command" => 5
    ]); */
    
    EnchantmentIdMap::getInstance()->register(EnchantmentIds::LOOTING, new Enchantment(KnownTranslationFactory::enchantment_lootBonus(), Rarity::RARE, ItemFlags::SWORD, ItemFlags::NONE, 3));
    EnchantmentIdMap::getInstance()->register(EnchantmentIds::FORTUNE, new Enchantment(KnownTranslationFactory::enchantment_lootBonusDigger(), Rarity::RARE, ItemFlags::DIG, ItemFlags::NONE, 3));

  }
  public function onDisable(): void {
     /** UTILS CONFIG
     * Save configs to onEnable
     * And Reload configs */
    // $this->utils->save();
     //$this->utils->reload();
  }

    public function onCommand(CommandSender $player, Command $cmd, string $l, array $args): bool {
        switch($cmd->getName()){
                case "enchanter":
                   $this->setCurrentFormToPlayer($player);
                break;
        }
        return true;
    }
  
  public function setCurrentFormToPlayer(Player $player){
      $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  
                  case "0":
                      $this->normalForm($player);
                      break;
                  case "1":
                      $this->specialForm($player);
                      break;
                  
              }
          }
      });
      
     // $levelMyXP = $player->getXp();
      $myCoinTypy = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
      $myCoinType = $myCoinTypy->myMoney($player->getName());
      
      $api->setTitle("§l§8MAGIC UI");
      $api->setContent("§r\n §r§7My Informations:\n\n §r§8■ §fMy Coins: §6".number_format($myCoinType, 0, "", ",")."\n\n §r§7Select the category you want:\n§r");
      $api->addButton("§l§8NORMALS ENCHANTS\n§r§7click to open", 0, 'textures/ui/icon_iron_pickaxe');
      $api->addButton("§l§8SPECIALS ENCHANTS\n§r§7click to open", 0, 'textures/ui/icon_iron_pickaxe');
      $api->addButton("§l§cEXIT PAGE\n§r§7click to open", 0, 'textures/ui/redX1');
      
      $api->sendToPlayer($player);
      return $api;
      
  }
  
  public function normalForm(Player $player){
      $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                      $this->toolForm($player);
                      break;
                  case "1":
                      $this->attackForm($player);
                      break;
                  case "2":
                      $this->armorForm($player);
                      break;
                  case "3":
                      $this->setCurrentFormToPlayer($player);
                      break;
              }
          }
      });
      $api->setTitle("§l§8NORMAL-ENCHANTS");
      $api->setContent("§r\n§r§7Select the category you want\n§r");
      $api->addButton("§l§8TOOLS\n§r§7pickaxe, axe, shovel, hoe", 0, 'textures/items/diamond_pickaxe');
      $api->addButton("§l§8ATTACK\n§r§7sword, axe", 0, 'textures/items/diamond_sword');
      $api->addButton("§l§8ARMOR\n§r§7chestplate, leggins, boots, helmet", 0, 'textures/items/diamond_chestplate');
      $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
      
      $api->sendToPlayer($player);
      return $api;
      
  }
  
  public function toolForm(Player $player){
      $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                      $this->makeForm($player);
                      break;
                  case "1":
                      $this->makeForm2($player);
                      break;
                  case "2":
                      $this->makeForm3($player);
                      break;
                  case "3":
                      $this->makeForm4($player);
                      break;
                  case "4":
                      $this->normalForm($player);
                      break;
              }
          }
      });
      $api->setTitle("§l§8TOOL-ENCHANTS");
      $api->addButton("§l§7EFFICIENCY\n§r§8update speed miner", 0, 'textures/ui/icon_iron_pickaxe');
      $api->addButton("§l§7UNBREAKING\n§r§8increases tool life", 0, 'textures/ui/icon_iron_pickaxe');
      $api->addButton("§l§7FORTUNE\n§r§8increases drops miner", 0, 'textures/ui/icon_iron_pickaxe');
      $api->addButton("§l§7SILK TOUCH\n§r§8break blocks smoothly", 0, 'textures/ui/icon_iron_pickaxe');
      $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
      
      $api->sendToPlayer($player);
      return $api;
  }
  
  public function makeForm(Player $player){
      $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("eff1-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1 - $discount;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "1":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x2 = $this->db->get("eff2-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x2){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x2 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x2 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x2){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 2;
                        
                        if(is_int($enchId)){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "2":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x3 = $this->db->get("eff3-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x3){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x3 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x3 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x3){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "3":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x4 = $this->db->get("eff4-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x4){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x4 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x4 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x4){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "4":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x5 = $this->db->get("eff5-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x5){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x5 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x5 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x5){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "5":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x6 = $this->db->get("eff6-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x6){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x6 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x6 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x6){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "6":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x7 = $this->db->get("eff7-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x7){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x7 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x7 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x7){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "7":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x8 = $this->db->get("eff8-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x8){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x8 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x8 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 8;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x8;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency VIII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x8){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 8;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x8;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency VIII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "8":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x9 = $this->db->get("eff9-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x9){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x9 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x9 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 9;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x9;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency IX§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x9){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 9;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x9;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency IX§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "9":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x10 = $this->db->get("eff10-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x10){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x10 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x10 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 10;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x10;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency X§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x10){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(15);
                        $level = 10;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x10;
                        $player->sendMessage("§r§aYou have successfully purchased §6efficiency X§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "10":
                    $this->toolForm($player);
                    break;
              }
          }
      });
      
      $x1 = $this->db->get("eff1-cost");
      $x2 = $this->db->get("eff2-cost");
      $x3 = $this->db->get("eff3-cost");
      $x4 = $this->db->get("eff4-cost");
      $x5 = $this->db->get("eff5-cost");
      $x6 = $this->db->get("eff6-cost");
      $x7 = $this->db->get("eff7-cost");
      $x8 = $this->db->get("eff8-cost");
      $x9 = $this->db->get("eff9-cost");
      $x10 = $this->db->get("eff10-cost");
      
      $api->setTitle("§l§8EFFICIENCY MENU");
      $api->addButton("§l§7EFFICIENCY I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY II\n§r§8Cost: §6©{$x2} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY IIII\n§r§8Cost: §6©{$x3} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY IV\n§r§8Cost: §6©{$x4} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY V\n§r§8Cost: §6©{$x5} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY VI\n§r§8Cost: §6©{$x6} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY VII\n§r§8Cost: §6©{$x7} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY VIII\n§r§8Cost: §6©{$x8} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY IX\n§r§8Cost: §6©{$x9} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7EFFICIENCY X\n§r§8Cost: §6©{$x10} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
      
      $api->sendToPlayer($player);
      return $api;
  }
  
  public function makeForm2(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("unb1-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool and !$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "1":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x2 = $this->db->get("unb2-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool and !$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x2){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x2 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x2 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x2){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "2":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x3 = $this->db->get("unb3-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool and !$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x3){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x3 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x3 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x3){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "3":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x4 = $this->db->get("unb4-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool and !$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x4){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x4 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x4 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x4){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "4":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x5 = $this->db->get("unb5-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool and !$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x5){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x5 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x5 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x5){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "5":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x6 = $this->db->get("unb6-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool and !$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x6){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x6 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x6 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x6){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "6":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x7 = $this->db->get("unb7-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool and !$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool or armor must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x7){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x7 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x7 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x7){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(17);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6unbreaking VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "7":
                    $this->toolForm($player);
                    break;
              }
          }
    });
          
      $x1 = $this->db->get("unb1-cost");
      $x2 = $this->db->get("unb2-cost");
      $x3 = $this->db->get("unb3-cost");
      $x4 = $this->db->get("unb4-cost");
      $x5 = $this->db->get("unb5-cost");
      $x6 = $this->db->get("unb6-cost");
      $x7 = $this->db->get("unb7-cost");
      
      $api->setTitle("§l§8UNBREAKING MENU");
      $api->addButton("§l§7UNBREAKING I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7UNBREAKING II\n§r§8Cost: §6©{$x2} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7UNBREAKING IIII\n§r§8Cost: §6©{$x3} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7UNBREAKING IV\n§r§8Cost: §6©{$x4} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7UNBREAKING V\n§r§8Cost: §6©{$x5} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7UNBREAKING VI\n§r§8Cost: §6©{$x6} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7UNBREAKING VII\n§r§8Cost: §6©{$x7} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
      
      $api->sendToPlayer($player);
      return $api;
  }
  
  public function makeForm3(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
      
      if(!is_null($data)){
        
        switch($data){
          case "0":
            $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("for1-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(18);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6fortune I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(18);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6fortune I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
            break;
          case "1":
            $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x2 = $this->db->get("for2-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x2){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x2 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(18);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6fortune II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x2){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(18);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6fortune II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
            break;
          case "2":
            $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x3 = $this->db->get("for3-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x3){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x3 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x3 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(18);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6fortune III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x3){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(18);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6fortune III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
            break;
          case "3":
            $this->toolForm($player);
            break;
        }
      }
    });
    
    $x1 = $this->db->get("for1-cost");
    $x2 = $this->db->get("for2-cost");
    $x3 = $this->db->get("for3-cost");
    
    $api->setTitle("§l§8FORTUNE MENU");
    $api->addButton("§l§7FORTUNE I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
    $api->addButton("§l§7FORTUNE II\n§r§8Cost: §6©{$x2} coins", 0, 'textures/items/book_enchanted');
    $api->addButton("§l§7FORTUNE IIII\n§r§8Cost: §6©{$x3} coins", 0, 'textures/items/book_enchanted');
    $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
    return $api;
  }
  
  public function makeForm4(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
      
      if(!is_null($data)){
        
        switch($data){
          case "0":
            $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("silk-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Tool){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(16);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6silk touch I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(16);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6silk touch I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
            break;
          case "1":
            $this->toolForm($player);
            break;
        }
      }
    });
    $x1 = $this->db->get("silk-cost");
    
    $api->setTitle("§l§8SILK-TOUCH MENU");
    $api->addButton("§l§7SILK TOUCH I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
    $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
    return $api;
  }
  
  public function attackForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
      
      if(!is_null($data)){
        
        switch($data){
          case "0":
            $this->sharpForm($player);
            break;
          case "1":
            $this->fireForm($player);
            break;
          case "2":
            $this->lootForm($player);
            break;
          case "3":
            $this->normalForm($player);
            break;
        }
      }
    });
    
    $api->setTitle("§l§8ATTACK-ENCHANTS");
    $api->addButton("§l§7SHARPNESS\n§r§8update attack damage", 0, 'textures/items/iron_sword');
    $api->addButton("§l§7FIRE_ASPECT\n§r§8add fire in oponent", 0, 'textures/items/iron_sword');
    $api->addButton("§l§7LOOTING\n§r§8increases drops in mobs", 0, 'textures/items/iron_sword');
    $api->addButton("§l§CBACK PAGE", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
    return $api;
    
  }
  
  public function sharpForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("sharp1-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased unbreaking I!");
                      }
                    }
                    break;
                  case "1":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x2 = $this->db->get("sharp2-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x2){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x2 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x2 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x2){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "2":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x3 = $this->db->get("sharp3-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x3){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x3 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x3 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x3){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "3":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x4 = $this->db->get("sharp4-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x4){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x4 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x4 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x4){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "4":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x5 = $this->db->get("sharp5-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x5){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x5 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x5 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x5){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "5":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x6 = $this->db->get("sharp6-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x6){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x6 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x6 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x6){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "6":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x7 = $this->db->get("sharp7-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool or armor must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x7){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x7 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x7 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x7){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(9);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6sharpness VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "7":
                    $this->attackForm($player);
                    break;
              }
          }
    });
          
      $x1 = $this->db->get("sharp1-cost");
      $x2 = $this->db->get("sharp2-cost");
      $x3 = $this->db->get("sharp3-cost");
      $x4 = $this->db->get("sharp4-cost");
      $x5 = $this->db->get("sharp5-cost");
      $x6 = $this->db->get("sharp6-cost");
      $x7 = $this->db->get("sharp7-cost");
      
      $api->setTitle("§l§8SHARPNESS MENU");
      $api->addButton("§l§7SHARPNESS I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7SHARPNESS II\n§r§8Cost: §6©{$x2} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7SHARPNESS IIII\n§r§8Cost: §6©{$x3} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7SHARPNESS IV\n§r§8Cost: §6©{$x4} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7SHARPNESS V\n§r§8Cost: §6©{$x5} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7SHARPNESS VI\n§r§8Cost: §6©{$x6} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7SHARPNESS VII\n§r§8Cost: §6©{$x7} coins", 0, 'textures/items/book_enchanted');
      
      $api->sendToPlayer($player);
      return $api;
  }
  
  public function fireForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("fire1-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(13);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6fire aspect I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(13);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6fire aspect I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                    break;
                  case "1":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x2 = $this->db->get("fire2-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword and !$player->getInventory()->getItemInHand() instanceof Axe){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x2){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x2 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x2 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(13);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6fire aspect II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x2){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(13);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6fire aspect II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "2":
                    $this->attackForm($player);
                    break;
              }
          }
    });
    
    $x1 = $this->db->get("fire1-cost");
      $x2 = $this->db->get("fire2-cost");
      
      $api->setTitle("§l§8FIRE ASPECT MENU");
      $api->addButton("§l§7FIRE ASPECT I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7FIRE ASPECT II\n§r§8Cost: §6©{$x2} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
      return $api;
    
  }
  
  public function lootForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("loot1-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(14);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6looting I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(14);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6looting I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                    break;
                  case "1":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x2 = $this->db->get("loot2-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x2){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x2 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x2 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(14);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6looting II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x2){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(14);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6looting II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "2":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x3 = $this->db->get("loot3-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Sword){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x3){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x3 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x3 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(14);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6looting III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x3){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(14);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6looting III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    }
                    break;
                  case "3":
                    $this->attackForm($player);
                    break;
              }
          }
    });
    
    $x1 = $this->db->get("loot1-cost");
      $x2 = $this->db->get("loot2-cost");
      $x3 = $this->db->get("loot3-cost");
      
      $api->setTitle("§l§8LOOTING MENU");
      $api->addButton("§l§7LOOTING I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7LOOTING II\n§r§8Cost: §6©{$x2} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7LOOTING III\n§r§8Cost: §6©{$x3} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
      return $api;
  }
  
  public function armorForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
      
      if(!is_null($data)){
        
        switch($data){
          case "0":
            $this->protectionForm($player);
            break;
          case "1":
            $this->normalForm($player);
            break;
        }
      }
    });
    $api->setTitle("§l§8AMOR-ENCHANTS");
    $api->addButton("§l§7PROTECTION\n§r§8protect the attack damage", 0, 'textures/items/diamond_chestplate');
    $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
      return $api;
  }
  
  public function protectionForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
          
          if(!is_null($data)){
              
              switch($data){
                  case "0":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x1 = $this->db->get("protect1-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x1){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x1 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x1){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 1;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x1;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection I§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                    break;
                  case "1":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x2 = $this->db->get("protect2-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x2){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x2 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x1 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x2){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 2;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x2;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection II§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                    break;
                  case "2":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x3 = $this->db->get("protect3-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x3){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x3 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x3 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x3){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 3;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x3;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection III§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                    break;
                case "3":
                    $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x4 = $this->db->get("protect4-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x4){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x4 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x4 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x4){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 4;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x4;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection IV§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                    break;
                case "4":
                  $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x5 = $this->db->get("protect5-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x5){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x5 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x5 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x5){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 5;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x5;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection V§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                  break;
                case "5":
                  $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x6 = $this->db->get("protect6-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x6){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x6 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x6 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x3){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 6;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x6;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection VI§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                  break;
                case "6":
                  $myMoney = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    $x7 = $this->db->get("protect7-cost");
                    $permission = $this->db->get("permission-discount");
                    $discount = $this->db->get("discount-in-coins");
                    
                    if(!$player->getInventory()->getItemInHand() instanceof Armor){
                      $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                      return;
                    }
                    if($myMoney->myMoney($player->getName()) < $x7){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if($myMoney->myMoney($player->getName()) < $x7 - $discount){
                      $player->sendMessage("§r§cYou not have money!");
                    }
                    if(!$player->hasPermission($permission)){
                      if($myMoney->myMoney($player->getName()) >= $x7 - $discount){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                      }
                    } else {
                      if($myMoney->myMoney($player->getName()) >= $x7){
                        $item = $player->getInventory()->getItemInHand();
                        $enchId = EnchantmentIdMap::getInstance()->fromId(0);
                        $level = 7;
                        
                        if($enchId !== null){
                          $item->addEnchantment(new EnchantmentInstance($enchId, (int) $level));
                        }
                        $player->getInventory()->setItemInHand($item);
                        $cost = $x7;
                        $player->sendMessage("§r§aYou have successfully purchased §6protection VII§a per §f{$cost}");
                          $myMoney->reduceMoney($player->getName(), $cost);
                       // $player->sendMessage("§r§aYou have successfully purchased fire aspect I!");
                      }
                    }
                  break;
                case "7":
                  $this->armorForm($player);
                  break;
              }
          }
    });
    $x1 = $this->db->get("protect1-cost");
    $x2 = $this->db->get("protect2-cost");
    $x3 = $this->db->get("protect3-cost");
    $x4 = $this->db->get("protect4-cost");
    $x5 = $this->db->get("protect5-cost");
    $x6 = $this->db->get("protect6-cost");
    $x7 = $this->db->get("protect7-cost");
      
      $api->setTitle("§l§8PROTECTION MENU");
      $api->addButton("§l§7PROTECTION I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7PROTECTION II\n§r§8Cost: §6©{$x2} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7PROTECTION III\n§r§8Cost: §6©{$x3} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7PROTECTION IV\n§r§8Cost: §6©{$x4} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7PROTECTION V\n§r§8Cost: §6©{$x5} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7PROTECTION VI\n§r§8Cost: §6©{$x6} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§7PROTECTION VII\n§r§8Cost: §6©{$x7} coins", 0, 'textures/items/book_enchanted');
      $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
      return $api;
  }
  
  public function specialForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data){
      if(!is_null($data)){
        switch($data){
          case "0":
            $player->sendMessage("In desenvolviment, coming soon in my github!");
            break;
          case "1":
            $this->setCurrentFormToPlayer($player);
            break;
        }
      }
    });
    $api->setTitle("§l§8SPECIAL-ENCHANTS");
    $api->addButton("§l§8EXPLOSION\n§r§7pickaxe, axe, shovel", 0, 'textures/ui/icon_iron_pickaxe');
    $api->addButton("§l§cEXIT", 0, 'textures/ui/redX1');
    
    $api->sendToPlayer($player);
    return $api;
  }
  /**
  public function expForm(Player $player){
    $api = new SimpleForm(function(Player $player, ?int $data) use ($ench){
      if(!is_null($data)){
        switch($data){
          case "0":
            $x1 = $this->db->get("exp1-cost");
            $myCash = $this->getServer()->getPluginManager()->getPlugin("Cash");
            $i = $player->getInventory()->getItemInHand();
            if ($ench == "Explosion I"){
              if ($myCash->myCash($player->getName()) < $x1){
                $player->sendMessage("§r§cYou not have cash!");
              }
              
              if(!$i instanceof Tool){
                $player->sendMessage("§l§4OPS! §r§cThe tool must be in your hand!");
                return;
              }
              if($myCash->myCash($player->getName()) >= $x1){
                
                $array = $i->getLore();
                $array[] = "Explosion I";
                $i->setLore($array);
                $player->getInventory()->setItemInHand($i);
                $myCash->removeCash($player->getName(), $x1);
                $player->sendMessage("§r§aYou have successfully purchased explosion I");
              }
            }
            break;
          case "1":
            $player->sendMessage("In desenvolviment! Actualizations coming soon in my github!");
            break;
          case "2":
            $player->sendMessage("In desenvolviment! Actualizations coming soon in my github!");
            break;
          case "3":
            $this->specialForm($player);
            break;
        }
      }
    });
    $x1 = $this->db->get("exp1-cost");
    
    $api->setTitle("§l§8EXPLOSION MENU");
    $api->addButton("§l§7EXPLOSION I\n§r§8Cost: §6©{$x1} coins", 0, 'textures/ui/icon_iron_pickaxe');
    $api->addButton("§l§7EXPLOSION II\n§r§8Cost: §cUnknown", 0, 'textures/ui/icon_iron_pickaxe');
    $api->addButton("§l§7EXPLOSION III\n§r§8Cost: §cUnknown", 0, 'textures/ui/icon_iron_pickaxe');
    $api->addButton("§l§cBACK PAGE", 0, 'textures/ui/redX1');
      
      $api->sendToPlayer($player);
      return $api;
  } */
  
}