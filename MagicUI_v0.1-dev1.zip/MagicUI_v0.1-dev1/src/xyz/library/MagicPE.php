<?php

namespace xyz\library;

use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\Listener;
use pocketmine\Item;
use pocketmine\item\ItemFactory;
use pocketmine\block\EnchantingTable;

use xyz\MagicUI;
use pocketmine\event\block\BlockBreakEvent;

use pocketmine\block\Block;
use pocketmine\world\World;
use pocketmine\world\Position;
use pocketmine\math\Vector3;

class MagicPE implements Listener{
    
    public function __construct(){
      
      $this->plugin = MagicUI::getInstance();
      
	  }
    
    /**
    * @param PlayerInteractEvent $ev
    */
    public function onInteract(PlayerInteractEvent $ev){
      if($ev->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
      if($ev->getBlock() instanceof EnchantingTable){
        $ev->isCancelled();
        $this->plugin->setCurrentFormToPlayer($ev->getPlayer());
      }
    }
}